import React, { Component } from "react";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import { TextField, Typography, Button } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import NativeSelect from "@material-ui/core/NativeSelect";
import InputLabel from "@material-ui/core/InputLabel";
import ConfirmBox from "./ConfirmBox";

const prices = { w180: 1000, w240: 900, w180: 850, jk: 640 };
const data = [
  { name: "W180", qantity: 1250 },
  { name: "jk", quantity: 1000 }
];
const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  paper: {
    padding: theme.spacing(2),
    color: theme.palette.text.secondary
  }
}));
const Paper1 = props => {
  const classes = useStyles();
  return <Paper className={classes.paper}>{props.children}</Paper>;
};
export default class Cart extends Component {
  constructor() {
    super();
    this.state = {
      amt: 0,
      open: false
    };
  }
  openPopUp = () => {
    this.setState({ open: true });
  };
  close = () => {
    this.setState({ open: false });
  };
  handleChange = e => this.setState({ amt: e.target.value });
  render() {
    let { open } = this.state;
    return (
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper1>
            <Typography>hi</Typography>
            <TextField
              id="outlined-full-width"
              label="Quantity in KG"
              style={{ margin: 8 }}
              placeholder="Enter Number of Cashews"
              helperText=""
              type="Number"
              margin="normal"
              InputLabelProps={{
                shrink: true
              }}
              variant="outlined"
            />
            <InputLabel htmlFor="age-native-helper">
              Quantity in Grams{" "}
            </InputLabel>
            <NativeSelect
              value={this.state.amt}
              onChange={this.handleChange}
              inputProps={{
                name: "age",
                id: "age-native-helper"
              }}
            >
              <option value={0.0}>0.00</option>
              <option value={0.25}>0.25</option>
              <option value={0.5}>0.50</option>
              <option value={0.75}>0.75</option>
            </NativeSelect>
            <Typography> AMT: 100</Typography>
            <Button variant="contained" size="medium" color="primary">
              Remove From Cart
            </Button>
          </Paper1>
        </Grid>
        <Grid xs={12} sm={3}>
          <Typography>Total amt : 1000 ₹</Typography>

          <div>
            <Button variant="contained" size="medium" color="primary">
              Buy Now
            </Button>
            <span>&nbsp;</span>
            <Button
              variant="contained"
              size="medium"
              color="primary"
              onClick={this.openPopUp}
            >
              Add More To Cart
            </Button>
          </div>
        </Grid>
        {open && (
          <ConfirmBox
            open={this.state.open}
            handleClose={this.close}
          ></ConfirmBox>
        )}
      </Grid>
    );
  }
}
