import React, { Component, Fragment } from "react";
import Card from "./Card";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import ConfirmBox from "./ConfirmBox";
import SearchContext from "../SearchContext";
//import classes from "*.module.css";
const Data = [
  {
    name: "W180",
    price: "1000",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "W210",
    price: "900",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "W240",
    price: "830",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "W320",
    price: "740",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "S240",
    price: "810",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "S320",
    price: "710",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "JK",
    price: "630",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "S",
    price: "750",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  },
  {
    name: "JH",
    price: "720",
    desc: "Pure natural nuts ,contains 180 nuts per kg",
    image: "/ruh"
  }
];
export default class Home extends Component {
  static contextType = SearchContext;
  render() {
    return (
      <Fragment>
        {/* <div className={classes.sectionWrapper}> */}

        <Grid container>
          {Data.map(
            item =>
              item.name.includes(this.context.toUpperCase()) && (
                <Grid item xs={12} sm={6} lg={4}>
                  <Card details={item}></Card>
                </Grid>
              )
          )}
        </Grid>
        <h3>
          You are searching for
          <SearchContext.Consumer>
            {value => <h4>{value}</h4>}
          </SearchContext.Consumer>
          {/* </div> */}
        </h3>
      </Fragment>
    );
  }
}
