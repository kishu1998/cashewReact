import React from "react";
import Navbar from "./Navbar";
import "./App.css";

function App() {
  return <Navbar />;
}

export default App;
